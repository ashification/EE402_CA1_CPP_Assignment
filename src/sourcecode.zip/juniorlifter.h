/*
 * juniorlifter.h
 *
 *  Created on: 9 Nov 2020
 *      Author: aisli
 */

#ifndef JUNIORLIFTER_H_
#define JUNIORLIFTER_H_





#endif /* JUNIORLIFTER_H_ */
